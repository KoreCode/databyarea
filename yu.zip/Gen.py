import os

BASE_DIR = "/storage/emulated/0/databyarea-site"
SITE = "https://databyarea.com"

STATES = [
("alabama","Alabama"),("alaska","Alaska"),("arizona","Arizona"),("arkansas","Arkansas"),
("california","California"),("colorado","Colorado"),("connecticut","Connecticut"),("delaware","Delaware"),
("florida","Florida"),("georgia","Georgia"),("hawaii","Hawaii"),("idaho","Idaho"),
("illinois","Illinois"),("indiana","Indiana"),("iowa","Iowa"),("kansas","Kansas"),
("kentucky","Kentucky"),("louisiana","Louisiana"),("maine","Maine"),("maryland","Maryland"),
("massachusetts","Massachusetts"),("michigan","Michigan"),("minnesota","Minnesota"),("mississippi","Mississippi"),
("missouri","Missouri"),("montana","Montana"),("nebraska","Nebraska"),("nevada","Nevada"),
("new-hampshire","New Hampshire"),("new-jersey","New Jersey"),("new-mexico","New Mexico"),("new-york","New York"),
("north-carolina","North Carolina"),("north-dakota","North Dakota"),("ohio","Ohio"),("oklahoma","Oklahoma"),
("oregon","Oregon"),("pennsylvania","Pennsylvania"),("rhode-island","Rhode Island"),("south-carolina","South Carolina"),
("south-dakota","South Dakota"),("tennessee","Tennessee"),("texas","Texas"),("utah","Utah"),
("vermont","Vermont"),("virginia","Virginia"),("washington","Washington"),("west-virginia","West Virginia"),
("wisconsin","Wisconsin"),("wyoming","Wyoming")
]

CATEGORIES = [
("cost-of-living", "Cost of Living", "Compare housing, groceries, transportation, and tax-related cost-of-living estimates by state."),
("utility-costs", "Utility Costs", "Compare electricity, gas, water, sewer, and trash utility cost estimates by state."),
("property-taxes", "Property Tax Rates", "Browse high-level property tax rate estimates and comparisons by state."),
("insurance-costs", "Insurance Costs", "Compare average insurance cost estimates (auto and home focused) by state.")
]


# --------------------------
# FILE HELPERS
# --------------------------
def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def write(path, content):
    ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

def asset_write(rel_path, content):
    path = os.path.join(BASE_DIR, rel_path.lstrip("/"))
    write(path, content)


# --------------------------
# CSS (full)
# --------------------------
def styles_css():
    return r""":root{
  --bg:#0b1220;
  --card:#0f1b33;
  --text:#eaf0ff;
  --muted:#a9b6d3;
  --line:rgba(255,255,255,.12);
  --accent:#6ea8ff;
  --gold:#e6c46b;
  --shadow:0 20px 50px rgba(0,0,0,.35);
  --radius:18px;
  --max:1100px;
}

*{box-sizing:border-box}
html,body{margin:0;padding:0}

body{
  font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;
  background:
    radial-gradient(1200px 600px at 20% 0%, rgba(110,168,255,.18), transparent 55%),
    radial-gradient(900px 500px at 85% 15%, rgba(230,196,107,.12), transparent 50%),
    var(--bg);
  color:var(--text);
  line-height:1.6;
}

a{color:var(--accent);text-decoration:none}
a:hover{text-decoration:underline}

.container{
  max-width:var(--max);
  margin:0 auto;
  padding:20px 16px 60px;
}

/* ===== NAV / HEADER ===== */

.nav{
  display:flex;
  flex-direction:column;
  gap:14px;
  padding:16px;
  border:1px solid var(--line);
  border-radius:var(--radius);
  background:rgba(15,27,51,.75);
  backdrop-filter:blur(10px);
  box-shadow:var(--shadow);
}

.brand{
  display:flex;
  align-items:center;
  gap:14px;
}

.logo{
  height:56px;
  width:auto;
  flex-shrink:0;
}

.brand-text strong{
  display:block;
  font-size:20px;
  line-height:1.1;
}

.brand-text span{
  font-size:13px;
  color:var(--muted);
}

.navlinks{
  display:flex;
  flex-wrap:wrap;
  gap:10px;
}

.pill{
  padding:10px 14px;
  border-radius:999px;
  border:1px solid var(--line);
  background:rgba(255,255,255,.05);
  font-weight:600;
}

/* ===== HERO ===== */

.hero{
  margin-top:22px;
  padding:26px 20px;
  border-radius:calc(var(--radius) + 10px);
  border:1px solid var(--line);
  background:linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.02));
  box-shadow:var(--shadow);
}

.hero h1{
  margin:0 0 10px;
  font-size:34px;
  line-height:1.15;
}

.hero p{
  margin:0;
  color:var(--muted);
  max-width:70ch;
}

.badges{
  display:flex;
  flex-wrap:wrap;
  gap:10px;
  margin-top:14px;
}

.badge{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:8px 12px;
  border-radius:999px;
  border:1px solid var(--line);
  background:rgba(255,255,255,.04);
  font-size:13px;
}

.dot{
  width:10px;
  height:10px;
  border-radius:50%;
  background:#5ff0b2;
}

.badge.gold .dot{background:var(--gold)}

/* ===== CTA BUTTONS ===== */

.cta{
  margin-top:18px;
  display:grid;
  gap:12px;
}

.cta a{
  padding:16px;
  text-align:center;
  border-radius:16px;
  border:1px solid var(--line);
  background:rgba(255,255,255,.06);
  font-weight:800;
  font-size:16px;
}

.cta a.primary{
  border-color:rgba(230,196,107,.5);
  box-shadow:0 0 0 1px rgba(230,196,107,.25);
}

/* ===== CATEGORY CARDS ===== */

.sectionTitle{
  margin:26px 0 10px;
  font-size:20px;
}

.grid{
  margin-top:14px;
  display:grid;
  grid-template-columns:repeat(12, 1fr);
  gap:14px;
}

.card{
  grid-column:span 12;
  padding:18px;
  border-radius:var(--radius);
  border:1px solid var(--line);
  background:rgba(15,27,51,.75);
  box-shadow:var(--shadow);
}

.card h2{margin:0 0 8px;font-size:18px}
.card p{margin:0 0 12px;color:var(--muted)}

.btn{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  padding:10px 14px;
  border-radius:14px;
  border:1px solid var(--line);
  background:rgba(255,255,255,.06);
  color:var(--text);
  font-weight:800;
}

.btn:hover{background:rgba(255,255,255,.1);text-decoration:none}

/* ===== LISTS ===== */

.breadcrumbs{margin:14px 0 0;color:var(--muted)}
.breadcrumbs a{color:var(--muted)}
.breadcrumbs a:hover{color:var(--text);text-decoration:none}

.searchRow{
  display:flex;
  gap:10px;
  flex-wrap:wrap;
  margin:12px 0 0;
}

.input{
  flex:1 1 260px;
  padding:12px 14px;
  border-radius:12px;
  border:1px solid var(--line);
  background:rgba(255,255,255,.04);
  color:var(--text);
  outline:none;
}

.input::placeholder{color:rgba(169,182,211,.7)}

.list{
  list-style:none;
  padding:0;
  margin:14px 0 0;
  display:grid;
  grid-template-columns:repeat(2, minmax(0, 1fr));
  gap:10px;
}

.item a{
  display:block;
  padding:12px 12px;
  border-radius:14px;
  border:1px solid var(--line);
  background:rgba(255,255,255,.04);
}

.item a:hover{background:rgba(255,255,255,.08);text-decoration:none}

/* ===== FOOTER ===== */

.footer{
  margin-top:30px;
  padding-top:18px;
  border-top:1px solid var(--line);
  color:var(--muted);
  font-size:13px;
}

/* ===== DESKTOP ===== */
@media (min-width:900px){
  .nav{
    flex-direction:row;
    align-items:center;
    justify-content:space-between;
  }

  .hero h1{font-size:44px}
  .logo{height:64px}
  .cta{grid-template-columns:repeat(2,1fr)}
  .card{grid-column:span 6}
  .list{grid-template-columns:repeat(4, minmax(0, 1fr))}
}
"""


# --------------------------
# HTML PARTS
# --------------------------
def head(title, desc, canonical_path):
    canonical = f"{SITE}{canonical_path}"
    return f"""<head>
  <meta charset="utf-8" />
  <title>{title}</title>
  <meta name="description" content="{desc}" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="/assets/styles.css" />
  <link rel="canonical" href="{canonical}" />
</head>"""

def nav():
    pills = []
    pills.append('<a class="pill" href="/">Home</a>')
    for slug, title, _ in CATEGORIES:
        pills.append(f'<a class="pill" href="/{slug}/">{title}</a>')

    return f"""
<div class="nav">
  <div class="brand">
    <img src="/assets/logo.png" alt="Data By Area logo" class="logo">
    <div class="brand-text">
      <strong>Data By Area</strong>
      <span>Costs • Rates • Public Data</span>
    </div>
  </div>
  <div class="navlinks">
    {''.join(pills)}
  </div>
</div>
""".strip()

def footer():
    return """<div class="footer">
  <p>
    <strong>Disclaimer:</strong> Informational estimates only. Costs and rates vary by household,
    provider, and local area. Not financial, legal, or tax advice.
  </p>
  <p>
    <a href="/about/">About</a> ·
    <a href="/privacy/">Privacy Policy</a> ·
    <a href="/contact/">Contact</a>
  </p>
  <p>© <span id="y"></span> DataByArea.com</p>
</div>
<script>
  document.getElementById("y").textContent = new Date().getFullYear();
</script>"""

# --------------------------
# PAGES
# --------------------------
def homepage():
    title = "Data By Area | Cost of Living, Utility Costs, Property Taxes & Insurance by State"
    desc = "Compare cost of living, utility costs, property tax rates, and insurance costs by area. Browse state pages across the United States."

    # Big CTA buttons like your mock
    ctas = []
    for i, (slug, t, _) in enumerate(CATEGORIES):
        cls = "primary" if i == 0 else ""
        ctas.append(f'<a class="{cls}" href="/{slug}/">{t}</a>')
    cta_html = "\n".join(ctas)

    cards = []
    for slug, t, d in CATEGORIES:
        cards.append(f"""
<div class="card">
  <h2>{t}</h2>
  <p>{d}</p>
  <a class="btn" href="/{slug}/">Browse states</a>
</div>
""".strip())

    return f"""<!doctype html>
<html lang="en">
{head(title, desc, "/")}
<body>
  <div class="container">
    {nav()}

    <div class="hero">
      <h1>Compare Costs & Rates by State</h1>
      <p>Cost of living, utilities, property taxes, and insurance — organized by location.</p>

      <div class="badges">
        <span class="badge"><span class="dot"></span> 50 states</span>
        <span class="badge">Fast pages</span>
        <span class="badge gold"><span class="dot"></span> Gold accents only</span>
      </div>

      <div class="cta">
        {cta_html}
      </div>
    </div>

    <h2 class="sectionTitle">Browse categories</h2>
    <div class="grid">
      {''.join(cards)}
    </div>

    {footer()}
  </div>
</body>
</html>"""

def category_page(cat_slug, cat_title, cat_desc):
    items = "\n".join([f'<li class="item"><a href="/{cat_slug}/{slug}/">{name}</a></li>' for slug, name in STATES])
    title = f"{cat_title} by State | Data By Area"
    desc = f"{cat_desc} Browse {cat_title.lower()} pages for all 50 states."

    return f"""<!doctype html>
<html lang="en">
{head(title, desc, f"/{cat_slug}/")}
<body>
  <div class="container">
    {nav()}

    <div class="hero">
      <h1>{cat_title} by State</h1>
      <p>{cat_desc} Use search to quickly find a state.</p>
      <div class="breadcrumbs"><a href="/">Home</a> › <span>{cat_title}</span></div>

      <div class="searchRow">
        <input id="q" class="input" placeholder="Search a state (e.g., Minnesota)..." />
      </div>
    </div>

    <h2 class="sectionTitle">Browse states</h2>
    <ul id="list" class="list">
      {items}
    </ul>

    {footer()}
  </div>

  <script>
    const q = document.getElementById('q');
    const items = Array.from(document.querySelectorAll('#list .item'));
    function filter(){{
      const term = q.value.trim().toLowerCase();
      items.forEach(li => {{
        const text = li.textContent.toLowerCase();
        li.style.display = text.includes(term) ? '' : 'none';
      }});
    }}
    q.addEventListener('input', filter);
  </script>
</body>
</html>"""

def state_page(cat_slug, cat_title, state_slug, state_name):
    title = f"{cat_title} in {state_name} | Data By Area"
    desc = f"{cat_title} estimates in {state_name}. Compare statewide averages and regional differences by area."
    canonical_path = f"/{cat_slug}/{state_slug}/"

    related = []
    for slug, t, _ in CATEGORIES:
        if slug != cat_slug:
            related.append(f'<li><a href="/{slug}/{state_slug}/">{t} in {state_name}</a></li>')
    related_html = "\n".join(related)

    return f"""<!doctype html>
<html lang="en">
{head(title, desc, canonical_path)}
<body>
  <div class="container">
    {nav()}

    <div class="hero">
      <h1>{cat_title} in {state_name}</h1>
      <p>
        High-level overview of {cat_title.lower()} in {state_name}. Figures are estimates and will be expanded over time.
      </p>
      <div class="breadcrumbs">
        <a href="/">Home</a> › <a href="/{cat_slug}/">{cat_title}</a> › <span>{state_name}</span>
      </div>
    </div>

    <div class="grid">
      <div class="card">
        <h2>What you can compare</h2>
        <p>Use this page as a starting point for understanding {cat_title.lower()} patterns in {state_name}.</p>
        <ul>
          <li>Statewide averages and regional variation</li>
          <li>How {state_name} compares to national benchmarks</li>
          <li>County/city detail as data is added</li>
        </ul>
      </div>

      <div class="card">
        <h2>Related {state_name} pages</h2>
        <p>Explore other categories for {state_name}.</p>
        <ul>
          {related_html}
        </ul>
        <a class="btn" href="/{cat_slug}/">Back to {cat_title} states</a>
      </div>
    </div>

    {footer()}
  </div>
</body>
</html>"""


# --------------------------
# BUILD
# --------------------------
def build():
    # Write CSS
    asset_write("/assets/styles.css", styles_css())

    # Homepage
    write(f"{BASE_DIR}/index.html", homepage())

    # Category hubs + state pages
    for cat_slug, cat_title, cat_desc in CATEGORIES:
        write(f"{BASE_DIR}/{cat_slug}/index.html", category_page(cat_slug, cat_title, cat_desc))
        for state_slug, state_name in STATES:
            write(f"{BASE_DIR}/{cat_slug}/{state_slug}/index.html",
                  state_page(cat_slug, cat_title, state_slug, state_name))

    print("DONE: styles.css + homepage + 4 hubs + 200 state pages generated.")

if __name__ == "__main__":
    build()