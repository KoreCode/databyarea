import os
from datetime import datetime

BASE_DIR = "/storage/emulated/0/databyarea-site"
SITE = "https://databyarea.com"

STATES = [
("alabama","Alabama"),("alaska","Alaska"),("arizona","Arizona"),("arkansas","Arkansas"),
("california","California"),("colorado","Colorado"),("connecticut","Connecticut"),("delaware","Delaware"),
("florida","Florida"),("georgia","Georgia"),("hawaii","Hawaii"),("idaho","Idaho"),
("illinois","Illinois"),("indiana","Indiana"),("iowa","Iowa"),("kansas","Kansas"),
("kentucky","Kentucky"),("louisiana","Louisiana"),("maine","Maine"),("maryland","Maryland"),
("massachusetts","Massachusetts"),("michigan","Michigan"),("minnesota","Minnesota"),("mississippi","Mississippi"),
("missouri","Missouri"),("montana","Montana"),("nebraska","Nebraska"),("nevada","Nevada"),
("new-hampshire","New Hampshire"),("new-jersey","New Jersey"),("new-mexico","New Mexico"),("new-york","New York"),
("north-carolina","North Carolina"),("north-dakota","North Dakota"),("ohio","Ohio"),("oklahoma","Oklahoma"),
("oregon","Oregon"),("pennsylvania","Pennsylvania"),("rhode-island","Rhode Island"),("south-carolina","South Carolina"),
("south-dakota","South Dakota"),("tennessee","Tennessee"),("texas","Texas"),("utah","Utah"),
("vermont","Vermont"),("virginia","Virginia"),("washington","Washington"),("west-virginia","West Virginia"),
("wisconsin","Wisconsin"),("wyoming","Wyoming")
]

CATEGORIES = [
("cost-of-living", "Cost of Living", "Compare housing, groceries, transportation, and tax-related cost-of-living estimates by state."),
("utility-costs", "Utility Costs", "Compare electricity, gas, water, sewer, and trash utility cost estimates by state."),
("property-taxes", "Property Tax Rates", "Browse high-level property tax rate estimates and comparisons by state."),
("insurance-costs", "Insurance Costs", "Compare average insurance cost estimates (auto and home focused) by state.")
]

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def write(path, content):
    ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

def head(title, desc, canonical_path):
    canonical = f"{SITE}{canonical_path}"
    # Simple OG tags (helps shares + credibility)
    return f"""<head>
  <meta charset="utf-8" />
  <title>{title}</title>
  <meta name="description" content="{desc}" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="/assets/styles.css" />
  <link rel="canonical" href="{canonical}" />
  <meta property="og:title" content="{title}" />
  <meta property="og:description" content="{desc}" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="{canonical}" />
</head>"""

def footer():
    return """<div class="footer">
  <p>
    <strong>Disclaimer:</strong> Informational estimates only. Costs and rates vary by household,
    provider, and local area. Not financial, legal, or tax advice.
  </p>
  <p>
    <a href="/about/">About</a> ·
    <a href="/privacy/">Privacy Policy</a> ·
    <a href="/contact/">Contact</a>
  </p>
  <p>© <span id="y"></span> DataByArea.com</p>
</div>
<script>document.getElementById("y").textContent = new Date().getFullYear();</script>"""

def topcard(show_navrow=True, show_home_cta=False, active_slug=None):
    # small nav row for non-home pages
    if show_navrow:
        pills = ['<a class="pill" href="/">Home</a>']
        for slug, title, _ in CATEGORIES:
            label = title.replace("Rates", "").strip()
            pills.append(f'<a class="pill" href="/{slug}/">{label}</a>')
        navrow = f'<div class="navrow">{"".join(pills)}</div>'
    else:
        navrow = ""

    # home CTA stack
    if show_home_cta:
        ctas = []
        for i, (slug, title, _) in enumerate(CATEGORIES):
            cls = "ctaBtn primary" if i == 0 else "ctaBtn"
            ctas.append(f'<a class="{cls}" href="/{slug}/">{title}</a>')
        home_cta = f"""
        <div class="ctaStack">
          {''.join(ctas)}
        </div>
        """
    else:
        home_cta = ""

    return f"""
    <div class="topcard">
      <div class="brandrow">
        <img src="/assets/logo.png" class="logo" alt="Data By Area logo">
        <div class="brandtext">
          <div class="brandname">Data By Area</div>
          <div class="brandtag">Costs • Rates • Public Data</div>
        </div>
      </div>

      <div class="heromini">
        <h1>Compare Costs &amp; Rates by State</h1>
        <p>Cost of living, utilities, property taxes, and insurance — organized by location.</p>

        <div class="badges">
          <span class="badge"><span class="dot"></span> 50 states</span>
          <span class="badge">Fast pages</span>
          <span class="badge gold"><span class="goldDot"></span> Gold accents only</span>
        </div>

        {home_cta}
        {navrow}
      </div>
    </div>
    """

def homepage():
    title = "Data By Area | Compare Costs & Rates by State"
    desc = "Compare cost of living, utility costs, property tax rates, and insurance costs by state. Fast, mobile-first, search-friendly pages."
    cards = []
    for slug, title2, desc2 in CATEGORIES:
        cards.append(f"""
        <div class="card">
          <h2>{title2}</h2>
          <p>{desc2}</p>
          <div class="actions"><a class="btn" href="/{slug}/">Browse states</a></div>
        </div>""")

    return f"""<!doctype html>
<html lang="en">
{head(title, desc, "/")}
<body>
  <div class="container">
    {topcard(show_navrow=False, show_home_cta=True)}

    <h2 class="sectionTitle">Browse categories</h2>
    <div class="grid">
      {''.join(cards)}
    </div>

    {footer()}
  </div>
</body>
</html>"""

def category_page(cat_slug, cat_title, cat_desc):
    items = "\n".join([f'<li class="item"><a href="/{cat_slug}/{slug}/">{name}</a></li>' for slug, name in STATES])
    title = f"{cat_title} by State | Data By Area"
    desc = f"{cat_desc} Browse {cat_title.lower()} pages for all 50 states."

    return f"""<!doctype html>
<html lang="en">
{head(title, desc, f"/{cat_slug}/")}
<body>
  <div class="container">
    {topcard(show_navrow=True, show_home_cta=False)}

    <h2 class="sectionTitle">{cat_title} by State</h2>
    <p style="color: var(--muted); margin: 6px 0 0;">{cat_desc}</p>

    <div class="searchRow">
      <input id="q" class="input" placeholder="Search a state (e.g., Minnesota)..." />
    </div>

    <ul id="list" class="list">
      {items}
    </ul>

    {footer()}
  </div>

  <script>
    const q = document.getElementById('q');
    const items = Array.from(document.querySelectorAll('#list .item'));
    function filter(){{
      const term = q.value.trim().toLowerCase();
      items.forEach(li => {{
        const text = li.textContent.toLowerCase();
        li.style.display = text.includes(term) ? '' : 'none';
      }});
    }}
    q.addEventListener('input', filter);
  </script>
</body>
</html>"""

def state_page(cat_slug, cat_title, state_slug, state_name):
    title = f"{cat_title} in {state_name} | Data By Area"
    desc = f"{cat_title} estimates in {state_name}. Compare statewide summaries and regional differences as data is added."
    canonical_path = f"/{cat_slug}/{state_slug}/"

    related = []
    for slug, t, _ in CATEGORIES:
        if slug != cat_slug:
            related.append(f'<li><a href="/{slug}/{state_slug}/">{t} in {state_name}</a></li>')
    related_html = "\n".join(related)

    return f"""<!doctype html>
<html lang="en">
{head(title, desc, canonical_path)}
<body>
  <div class="container">
    {topcard(show_navrow=True, show_home_cta=False)}

    <h2 class="sectionTitle">{cat_title} in {state_name}</h2>
    <p style="color: var(--muted); margin: 6px 0 0;">
      This page provides a high-level overview of {cat_title.lower()} in {state_name}. Figures are informational estimates.
    </p>

    <div class="grid">
      <div class="card">
        <h2>What you can compare</h2>
        <p>Use this page as a starting point for understanding {cat_title.lower()} patterns in {state_name}.</p>
        <ul>
          <li>Statewide averages and regional variation</li>
          <li>How {state_name} compares to national benchmarks</li>
          <li>Differences across counties and major cities (as data is added)</li>
        </ul>
      </div>

      <div class="card">
        <h2>Related {state_name} pages</h2>
        <p>Explore other categories for {state_name}.</p>
        <ul>
          {related_html}
        </ul>
        <div class="actions" style="margin-top: 12px;">
          <a class="btn" href="/{cat_slug}/">Back to {cat_title} states</a>
        </div>
      </div>
    </div>

    {footer()}
  </div>
</body>
</html>"""

def simple_page(slug, title, body_html, desc):
    return f"""<!doctype html>
<html lang="en">
{head(title, desc, f"/{slug}/")}
<body>
  <div class="container">
    {topcard(show_navrow=True, show_home_cta=False)}
    <div class="card" style="margin-top: 18px;">
      <h2>{title}</h2>
      {body_html}
    </div>
    {footer()}
  </div>
</body>
</html>"""

def generate_sitemap(urls):
    lastmod = datetime.utcnow().strftime("%Y-%m-%d")
    items = "\n".join([f"<url><loc>{u}</loc><lastmod>{lastmod}</lastmod></url>" for u in urls])
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{items}
</urlset>
"""

def build():
    urls = []

    # homepage
    write(f"{BASE_DIR}/index.html", homepage())
    urls.append(f"{SITE}/")

    # legal/info pages
    about_html = "<p>Data By Area is a simple directory of location-based comparisons across the United States.</p><p>We publish fast, clean pages that help you explore broad cost and rate patterns by state.</p>"
    privacy_html = "<p>We do not collect personal information on this static site. Basic analytics may be added later to understand traffic trends.</p>"
    contact_html = "<p>For questions or suggestions, add a contact email later (or use a form if you decide to go dynamic).</p>"

    write(f"{BASE_DIR}/about/index.html", simple_page("about", "About", about_html, "About Data By Area."))
    write(f"{BASE_DIR}/privacy/index.html", simple_page("privacy", "Privacy Policy", privacy_html, "Privacy information for Data By Area."))
    write(f"{BASE_DIR}/contact/index.html", simple_page("contact", "Contact", contact_html, "Contact Data By Area."))

    urls += [f"{SITE}/about/", f"{SITE}/privacy/", f"{SITE}/contact/"]

    # hubs + state pages
    for cat_slug, cat_title, cat_desc in CATEGORIES:
        write(f"{BASE_DIR}/{cat_slug}/index.html", category_page(cat_slug, cat_title, cat_desc))
        urls.append(f"{SITE}/{cat_slug}/")

        for state_slug, state_name in STATES:
            path = f"{BASE_DIR}/{cat_slug}/{state_slug}/index.html"
            write(path, state_page(cat_slug, cat_title, state_slug, state_name))
            urls.append(f"{SITE}/{cat_slug}/{state_slug}/")

    # sitemap + robots
    write(f"{BASE_DIR}/sitemap.xml", generate_sitemap(urls))
    write(f"{BASE_DIR}/robots.txt", f"User-agent: *\nAllow: /\nSitemap: {SITE}/sitemap.xml\n")

    print(f"DONE: {len(urls)} URLs + sitemap.xml + robots.txt")

if __name__ == "__main__":
    build()